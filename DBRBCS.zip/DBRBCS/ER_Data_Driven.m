

%%  使用ER推理方法进行新样本的推理   被调用的    想办法将其泛化，即适应于不同的数据集

%--读入测试样本的读入
%%  2022.0616 :调整为对top k个规则进行融合

function [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k)

  FES  =  AA;   %AA是规则前提部分


num_final=0;

for k_d =  1:size(Test_Data,1)
    
    Sam_ple  =  Test_Data(k_d,:);  %顺次读取数据
    for j=1:size(FES,1)                 %对每一条规则递增
        for k=1:size(FES,2)             %对每个特征递增
            ZC=FES(j,k);            %通过FES里的标签调用均值矩阵里的均值  %加个判断语句
            if ZC==0
                cfes(j,k)  =  1;      %为0时，后面选择最小值作为当前类别隶属度，如果全为0，
                continue                   %那么，会出现问题是直接是1，会错误
            else               %解决策略，在调用之前，先将全为0的行删除，可以直接调用
                ZM   =  men(k,ZC);     %均值
                cfes(j,k)=memship(Sam_ple(:,k+1),ZM,sigmaf(k));   %sigmaf是方差
            end
        end
    end   %当j全部运行完后，一个样本对5条规则的所有隶属度计算出来存放在cfes矩阵中
    Cheng_ji = prod(cfes,2);
    Cheng_ji = Cheng_ji.^(  1/(  size(AA,2)  )   );     % 先乘积，再开更    ——————————   计算出来的激活度 
    
    % 通过激活度，选取前 K 条  规则进行融合
    [top_fengbu , in_top_index] = sort(Cheng_ji,1,'descend');
    
     if size(in_top_index,1) < top_k
         top_k_l = size(in_top_index,1);
     else
         top_k_l = top_k;
     end
    
    for top = 1:top_k_l   %  只选择top_k个规则进行融合
        
        Lin_Shi(:,:,top) =  Ini_e ; 
        Lin_Shi(:,2,top) =  WTf(:,2, in_top_index(top) )   * top_fengbu(top)  ;
        Lin_Shi(size(Lin_Shi,1),2,top) = Lin_Shi(size(Lin_Shi,1),2,top) * top_fengbu(top)  + 1 - top_fengbu(top); 
    end


%     for er_1 = 1:size(WTf,3)
%       WTf(:,3,er_1) = WTf(:,2,er_1) * min_cfes(er_1);  
%       WTf(size(WTf,1),3,er_1) = WTf(size(WTf,1),3,er_1) * min_cfes(er_1)+1-min_cfes(er_1); %  有做修改（0329）
%     end     %  类似更新置信分布
    
    %  对置信分布进行更新完成，下一步进行 多个置信分布进行融合
%     final_er=[1 0 0 0 ;2 0 0 0 ;3 0 0 0 ]  ;                    %暂时是3个
    final_er = Ini_e;
    final_er(:,2) = Lin_Shi(:,2,1) ;   %  可以调用之前编写的函数 
    for er_2 = 2:top_k_l
       final_er(:,3)  =  Lin_Shi(:,2,er_2) ;
       final_er(:,2)  =  E_BRB(final_er)';
    end
    
    %全部融合完成后，进行判断标签
    
    Fengbu_arry = final_er;    %  完整的分布
    
    final_er(size(final_er,1),:) = [];     %删去置信框架的置信分布
    [~,final_index]=max(final_er(:,2));   %  分布中只选第2列    
        tag_brb  =    final_er(final_index,1);
    if final_er(final_index,1)==Sam_ple(1)
        num_final = num_final+1;
    end    
end  %大循环，读取样本
   ac_er=num_final/size(Test_Data,1);
end