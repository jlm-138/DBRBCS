

%%
% 将原型规则前提转换成语言标签的形式。

function [AA,men,sigmaf,WTf,Ini_e,top_k,aaa_ZUICHU,Nl]=FZ_P2R(top_k,FF,A,Store_Data,Wp,cnt,Ini_e,Test_Data)

%% 2022-----二

%%   基本不用进行改变    2022.09.28

%%   12.17   对规则前提的精细化操作

WP2 = Wp;        %读入wp矩阵
cnt2 = cnt;      %读入数量矩阵
lamda = 0.01;    %设置拉姆达的值---------------------------------------------------可更改
Nl = 3;          %设置语言标签数量-------------------------------------------------可更改
[min_a,index1] = min(WP2);
[max_a,index] = max(WP2);
NL = Nl*ones(1,size(WP2,2));    %该语言标签数量可以由专家指定-------------------------------可更改
%   NL=[2 2 3 2 3 2 3 3 2];
 %% 步骤二
for i1=1:size(WP2,2)     %i1表示在第几个特征上的模糊集的信息
    Vmin(i1)=min_a(i1);
    Vmax(i1)=max_a(i1);
    res(i1)=(Vmax(i1)-Vmin(i1))/(NL(i1)-1);
    sigmaf(i1)=sqrt(-res(i1)^2/(sqrt(2)*log(lamda)));
    men(i1,1)=Vmin(i1);
    for j1=2:NL(i1)
        men(i1,j1) =men(i1,j1-1)+res(i1);
    end 
end
  %% 步骤三，映射规则前提
  % 不管具体有几个语言标签，只管映射过来的数目
  for h=1:size(WP2,1)
      for y=1:size(WP2,2)
          for ss=1:Nl
          cc=WP2(h,y)-men(y,ss);
          dd(1,ss)=abs(cc);
          end
          [min_cc,dex]=min(dd);
          AA(h,y)=dex;    
      end
  end
   %%  
   
   
   %%  2022.06.16  
   % 用转化后的规则进行计算规则结论的置信分布。
   
             arry_ini =  Ini_e;
          

        for k=1:size(Wp,1)
            WT(:,:,k) = arry_ini;    %    过程中的置信分布
            WTf(:,:,k) = arry_ini;   %  最终的置信分布
        end

   for m_h1=1:size(Store_Data,1)            %每次循环，代表在当次的规则中进行计算------      m_h1代表规则数
        clear fire;  %   0329晚，添加
       for m_h2=1:size(Store_Data,2)
           S_index = Store_Data(m_h1,m_h2);   %有许多零在存储阵中，因此设置一个判断语句，为零，下一次，非零，继续
           if S_index==0
               continue
           end           
           p_h  =  A(S_index,:);    %    逐条提取样本        
%%  06.16 修正--改成利用转化后的规则进行计算隶属度
        for j=1:FF                                                             %遍历每一个维度
            lb_6 = AA(m_h1,j);   %  调用出语言标签
            if lb_6 ==0
                fire(m_h1,j) =1;
                continue
            else
                ZM  =  men(j,lb_6);     %均值
                fire(m_h1,j)  =  memship(p_h(:,j+1),ZM,sigmaf(j));   %sigmaf是方差
            end
        end
        M_N = prod(  fire(m_h1,:)   );
        M_N = M_N.^(1/FF);            
               %检测是否为第一个矩阵，若是，只进行赋值，若不是，则进行融合                                             
               if sum( WT(p_h(1),p_h(1)+1,m_h1) ) == 0  %是初始的，进行赋值
                  WT(p_h(1),p_h(1)+1,m_h1)   = M_N;%  max_M;
                  WT(size(arry_ini,1),p_h(1)+1,m_h1)   =  1-M_N;% 1-max_M;       %  22.2.17 修 改  泛化了。
                  WT(  p_h(1),size(arry_ini,2),m_h1)   =   1;                            %   最后 一 列  用来计数
               else             %如果不是初始的，则开始融合
                   arry_ini = Ini_e ;         %  每次进行初始化一次？  初始化是为了方便调用
                   arry_ini(:,2)=WT(:,p_h(1)+1,m_h1);                      %将原始的提取过来
                   arry_ini(p_h(1),3) = M_N  ;          %  max_M;                               %将新的赋值过去
                   arry_ini(size(arry_ini,1),3)= 1-M_N; %   1-max_M;             %  进行泛化修改
                   WT(:,p_h(1)+1,m_h1) = E_BRB(   arry_ini  )';      % **   第一次调用融合函数
                   WT(p_h(1),size(arry_ini,2),m_h1)   =  WT(p_h(1),size(arry_ini,2),m_h1)+1 ;                         %计数
               end                                             
       end    %  遍历每条规则中包含的样本       
   end   %  挨个遍历规则
   
   %%  以上，已经将类内的融合完成，接下来，开始进行类间融合↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
   
   
      WT_=WT;      %   WT_   暂存中间结果  之后也没用   
      %  计算样本占比
   for m_f1=1:size(WT,3)             
       pi_1 = sum(WT(:,size(WT,1)+1,m_f1));       %  +1代表除常规外，  额外加的 一列  存储数值的   
       for m_f2=1:size(WT,1)       
           WT(m_f2,size(WT,1)+1,m_f1)  =  WT(m_f2,size(WT,1)+1,m_f1)/pi_1;      
       end              
   end
   
      %% 原本进行折扣的部分 
      %  打折扣的函数
   f_n  =  size(arry_ini,1)-1;       %  2.17修改的！！
   f_m  =  size(arry_ini,2)-1;
   
   for i_o = 1:size(WT,3)     % 大循环
       
       index_d  =  find(   WT(:,size(WT,2),i_o) >0 );   % 即，找出存在的，有数值的
       for i_d = 1 : size (index_d,1)
           
       factor    =   WT( index_d(i_d) ,  size(WT,2)  ,i_o)  ;  % 提取出折扣因子的数值
       WT(  index_d(i_d),  index_d(i_d)+1  ,i_o)    =   WT(  index_d(i_d),  index_d(i_d)+1  ,i_o)*factor;
       WT(  size(arry_ini,1),  index_d(i_d)+1  ,i_o)   =  WT(  size(arry_ini,1),  index_d(i_d)+1  ,i_o)*factor + (1-factor);
       end       
   end
   
   %  06.16   以上，是首先将对应的mass函数进行了一个折扣。每一个置信分布

   

   
   
   %%  检测函数↑

   
   %进行融合
           for m_f1=1:size(WT,3)      %选页
               mf_index = find(   WT(:,size(WT,2),m_f1) >0 );   %找出当前结论中有哪几行是非零的，即需要融合的

               if size(mf_index,1)==1    %   1  还是  2
                   WTf(:,2,m_f1)  =  WT(  : , mf_index(1)+1 , m_f1);
                   continue
               end               
               GuoDu_f1  =  Ini_e;
               GuoDu_f1(:,2)  =  WT(  :,mf_index(1)+1,m_f1) ;
               for m_f2  =  2:size(mf_index,1)       %选行
                   
                   GuoDu_f1(:,3)  =  WT(  :,mf_index(m_f2)+1,m_f1) ;
                   GuoDu_f1(:,2)  =  E_BRB(   GuoDu_f1  )';                       
               end          % 行循环结束                   
               WTf(:,2,m_f1) = GuoDu_f1(:,2);     %不能直接进行此操作，原本接近于0的将会直接赋值为0，但可以留下作为参照。                       
           end  % 大循环里的  矩阵页
           
   WT1 =  WTf;        
   
   %%  有个问题，相同规则前提的规则实际上是可以融合变成一个规则  ！！！
   you = unique( AA,'rows' );
   for  k = 1 : size(you,1)
       
       Rule_A = AA(k,:);
       RULE  =  Rule_A .* ones( size(AA,1), size(AA,2) );
       DE_RULE  = abs( RULE  -AA  );
      sum_de =  sum (DE_RULE,2);
      de__index  =  find(sum_de==0);  %  找到和第一条规则想等的规则
      
      % 1 存在相同的
      % 2 不存在相同的
      if  size(de__index,1) > 1
          
          GuoDu_f1  =  Ini_e;
          GuoDu_f1(:,2)  =  WTf(  :,2,de__index(1) ) ;
          
          for plc  =  2:size(mf_index,1)       %选行
              
              GuoDu_f1(:,3)  =  WTf(  :,de__index(plc)  ) ;
              GuoDu_f1(:,2)  =  E_BRB(   GuoDu_f1  )';
              
          end          % 行循环结束
          
          WTf(:,2, k) =  GuoDu_f1(:,2) ;
          
          de__index(1) = [];
          
          % 融合完成后进行删除对应的行 
          AA(de__index,:)      =  [];
          WTf(:,:,de__index)   =  [];
%           you = size(AA,1);
          
      else   % 2 不存在相同的
          continue
          
      end

   end
   
   %%  在这之间进行修改
%    Test_Data=Test_dat1;
   
   [aaa_ZUICHU,~,~,~,~]=ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k);    %   返回值为精度与预测值
   disp( aaa_ZUICHU)
  
  DATA_DRIVEN_RULE = AA ; %将数据驱动规则库提取出来
  data_driven_wt = WTf;    

end