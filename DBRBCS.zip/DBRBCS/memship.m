%-计算隶属度的函数
function [beta]=memship(x,uc,sigmc)
beta=exp(-((x-uc)/sigmc)^2);
end