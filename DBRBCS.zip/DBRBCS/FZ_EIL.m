


%%
% 专家在回路的置信规则更新

function [td_1]=FZ_EIL(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k,DOI,Nl)


%%  2022.07.18   数据是依次进入   有新样本的出现
    age =  zeros(1,size(AA,1))  ;   %   生成一个全零矩阵，代表初始规则年龄
 %%  在开始之前，先对测试集进行一次预测
    [ac_er,~,~,~ , ~] =  ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k) ;
    disp(ac_er)
    ANSWER(1,1) =ac_er; 
 
    %%   相关参数设置
            omicro = 0.01;           %   预先设定的阈值
            a = 2;                   %   阶跃函数近似值中的一个参数。    
            de_num  =  50;           %   设置迭代次数-梯度下降法                           
            huip = 30 ;              %   规则删除阈值   【可以设置具体数值，也可以利用比例设置】
                        
 for p11 = 1 : size(DOI,1)
     
     samp_l = DOI(p11,:)  ;   %   读入第一个数据
     
     % 首先利用现有模型对进入的样本进行预测
     [~,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,samp_l,men,sigmaf,WTf,Ini_e,top_k) ;
     
     if  tag_brb  ==  samp_l(1)
         aJILUJZ(p11)  =  1;
     end
     
     popop(p11)= top_fengbu(1);
     % 分类准确率，硬标签，置信分布，激活度排名，激活度排序对应的规则
     % 首先判断预测值与真实值是否相等，以及真实值是否是未出现过的样本
     
     %%  此时，获取到真实标签
     % 判断是否是新出现的标签，如果是，添加规则
     
     %% 有新标签，添加一条规则
     if samp_l(1) > size(WTf,1)-1                   %  是新出现的标签       【只是在实验的时候设定为新出现的标签的】
         
         for y= 2:size(samp_l,2)
             for ss=1:Nl
                 cc = samp_l(y)-men(y,ss);
                 dd(1,ss) = abs(cc);
             end
             [min_cc,dex]=min(dd);
             A_new(y)  =  dex;                 %  生成的新规则，等待加入到规则库中
         end
         
         %%
         n_class  =  size(WTf,1)-1+1  ;  % 相当于在原本的基础上，又增加了一个标签
         A_new_WT  =  zeros(  n_class+1, n_class+2  );
         K_class  =  linspace(1 , n_class+1,  n_class+1  );
         A_new_WT(:,1)  =    K_class' ;
         
         A_new_WT(size(A_new_WT,1)-1,size(A_new_WT,1)-1) = 1;      %   此处是先暂定，应该用推理出来的结果进行赋值 ！！！！！
         A_new_WT(size(A_new_WT,1),size(A_new_WT,1)) = 0;
         %%
         
         %  由于多加了一个标签类，因此需要对之前的所有的结论部分矩阵进行加一行的操作
         % 在倒数第二行的位置，加入一行新标签对应的行
         %  n_class  =  size(WTf,1)-1+1  ;  % 相当于在原本的基础上，又增加了一个标签
         
         for  J_1 = 1:size(WTf,3)
             
             new_WTf(:,:,J_1)  =  zeros(  n_class+1, n_class+2  );
             K_class  =  linspace(1 , n_class+1,  n_class+1  );
             new_WTf(:,1,J_1)  =    K_class' ;
             new_WTf(1:size(WTf,1)-1,2,J_1)  = WTf(1:size(WTf,1)-1,2,J_1);
             new_WTf(size(new_WTf,1),2,J_1)  = WTf(size(WTf,1),2,J_1);
         end
         WTf = new_WTf;    %  更新完成后，赋值返回
         
         AA   =   [AA;A_new];    %  添加一条新规则    规则前提
         
         %  当执行到这时，应该就要对年龄矩阵操作一次，对新规则年龄赋值为  0  ，其他规则
         
         age(  size(age,2)+1  ) = 0;
         age(  1:size(age,2)-1  ) =   age(  1:size(age,2)-1  )  +1;
         
         WTf(:,:,size(WTf,3)+1)  =  A_new_WT;    %   添加一条新的规则结论。
     end
     
     %%  正确分类，进行更新结论（只更新激活度最大的规则对应的结论）     在此处添加一条因为激活度过小，应该添加一条新的规则
     
     if top_fengbu(1)  <  omicro   %  小于预先设定值，因此需要添加一条规则
         samp_l1 = samp_l;
         samp_l1(1) = [];
         for y= 1:size(samp_l1,2)
             for ss=1:Nl
                 cc = samp_l1(y)-men(y,ss);
                 dd(1,ss) = abs(cc);
             end
             [min_cc,dex]=min(dd);
             A_new(y)  =  dex;                 %  生成的新规则，等待加入到规则库中
         end
         
         n_class  =  size(WTf,1)-1  ;  % 相当于在原本的基础上，又增加了一个标签
         A_new_WT1  =  zeros(  n_class+1, n_class+2  );
         K_class  =  linspace(1 , n_class+1,  n_class+1  );
         A_new_WT1(:,1)  =    K_class' ;
         
         A_new_WT1( samp_l(1) ,2) = 1;      %   此处是先暂定，应该用推理出来的结果进行赋值 ！！！！！
         A_new_WT1(size(A_new_WT1,1),2) = 0;
         
         AA   =   [AA;A_new];    %  添加一条新规则    规则前提
         
         WTf(:,:,size(WTf,3)+1) = A_new_WT1;    %  更新完成后，赋值返回
         
         age(  size(age,2)+1  ) = 0;
         age(  1:size(age,2)-1  ) =   age(  1:size(age,2)-1  )  +1;
         
     end
     
     if top_fengbu(1)  >  omicro   %  小于预先设定值，因此需要添加一条规则
         
         if samp_l(1)  ==  tag_brb   % 正确分类
             
             in_top_index   ;  %  规则激活度的排名，通过其进行选择部分规则的结论进行更新   修正
                
             N_H_TQ =  WTf(:,:,in_top_index(1));   %   将对应的规则结论提取出来，赋值给中间过度矩阵             
             N_H_TQ(samp_l(1),3)  = top_fengbu(1) ;   %  将要融合的新样本进行赋值操作，激活度作为             
             N_H_TQ(size(N_H_TQ,1),3)  =   1-top_fengbu(1);             
             WTf(:,2,in_top_index(1))   =    E_BRB(  N_H_TQ   )';    %   每次只执行一次进行
     %        进行更新现有规则，分对，奖励机制
             
             %%    因为此时是对前三条规则进行激活的，因此，规则年龄赋值为 0  的只是前3条规则  ，  注意，有可能是不足 3 条的             
             age = age+1;   %  先对所有的进行加一，然后再将个别的赋值为  0
             for ak = 1:3
                 age(  in_top_index(ak)  )  = 0;
             end 
             
         else                                                        %  分类错误，进行惩罚并添加对应规则的置信度
             
             %% 错误分类时，利用  梯度下降法对相应的结论进行修正。
             % 在此处应该是有一个循环的 设置，   梯度下降的迭代循环             
             %%  想法，梯度下降不能只对一条规则进行更改  要将其他规则也考虑进来，  现在先采用一种循环更改方式             
             for  k=1:de_num                 
                 %   每循环一次时，都应该对样本进行分类一次
                 [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,samp_l,men,sigmaf,WTf,Ini_e,top_k) ;
                 
                 if  samp_l(1)  ==  tag_brb    %   表示梯度下降优化完成，跳出迭代循环
                     break
                 end
                 
                 H   =   (  Fengbu_arry(samp_l(1),2)+1  )/( 1+ Fengbu_arry(tag_brb,2)  );  %  融合后的比值，   预测值:真实值
                 J   =  1/(   1+  (  exp( a*(1-H)  )  )  );    % 目标函数                 
                 %   下一步，根据损失函数，及其导数，开始对求  delta_beta
                 %   首先确定对   哪一条规则的  哪一个置信度进行更新。
                 %  即，对激活度最大的规则的置信度进行更新。                 
                 S_1  =  (  a * exp( a* (1-H)  )  )  /   ( 1+  exp( a*(1-H)  )  )^2   ;                 
                 %%   此处开始编写求导部分
                 %   将要融合的结论个数是top_k个，因此，只考虑  in_top_index  里面的前k个索引值。
                 if size(in_top_index,1) < top_k
                     top_k_l = size(in_top_index,1);
                 else
                     top_k_l = top_k;
                 end
                 
                 %%  09-21   调整：循环更改，而不是只对一条规则进行更改
                 in1dex = mod(k,top_k_l);
                 if in1dex==0
                     in1dex=top_k_l;
                 end                 
                 for   u  =  1 : top_k_l    % 有时候，可能规则数目达不到top_k个    此值应该是在当前循环时，都可以应用
                     BN(:,u) = WTf(:,2,in_top_index(u));         %   此时，BN中存放着需要融合的规则的结论部分
                 end                                            %   需要更改的实际上应该是激活度最大的规则结论中真实标签所对应的数值
                 
                 %  即 更新的参数位置是  BN中的第一列，第  samp_l(1)   行
                 %  首先计算等式  K  和  F  的值   之后的计算  直接利用BN中的数值进行计算                 
                 % 进行折扣操作
                 for j = 1:size(BN,2)
                     BN_1( 1:size(BN,1)-1 ,j )  =   BN( 1:size(BN,1)-1 ,j ) * top_fengbu (j) ;
                     BN_1( size(BN,1) ,j )  =   1  -  sum(  BN_1( 1:size(BN,1)-1 ,j )    )   ;
                 end                                   
                 
                 for  v  =  1  :  size(BN,2)    %  类似于对规则的递增
                     pod(v) =  BN_1( samp_l(1)  ,v) + BN_1(  size(BN_1,1),v )  ;        %   注意，此处应该将激活度考虑进来  【得详细一点】  √
                 end
                 
                 %%  临时放置   in1dex =1
                 
                 F_N   =  prod(pod)  -  prod(  BN_1( size(BN,1) ,: )  ) ;   %  对等式中的  F  求值     %%  有乘积  有可能出现乘后变  0  的情况   
                 F_N_1 =  top_fengbu (in1dex) *  prod(  BN_1( size(BN,1) ,: )  )/   BN_1 ( size(BN_1,1) , in1dex )  ;  %  对 等式中的 F 式进行求导11
                 %  接下来，对  K 相关式子开始 进行求值                 
                 for  v  =  1  :  size(BN,2)
                     for vv = 1:size(BN,1)-1
                         BN_L ( vv ,v ) =  BN_1(vv,v ) +BN_1( size( BN_1,1 )  ,v )  ;
                     end
                 end
                 
                 K_0  =    sum( prod(BN_L,2) )  - ( size(BN_L,1)-1-1 )* prod( BN_1( size(BN,1) ,: )    )    ;
                 K_N  =  1/K_0  ;     %   求出等式  K
                 K_N_1  =   ( size(BN_1,1)  -1 - 1  )*  (  top_fengbu (in1dex) *  prod(  BN_1( size(BN,1) ,: )  )/   BN_1 ( size(BN_1,1) , in1dex ) )  ;
                 K_N_1  = ( 1/(K_0)^2 )  *  K_N_1  ;
                 
         %%
                 
                 Br_1  =  F_N *  K_N_1 + K_N  *  F_N_1  ;   %  KF +  FK 的 组合  

                 
                 S_2  =  - ( (1+ Fengbu_arry(tag_brb,2) )* Br_1  / (  1 +  Fengbu_arry( samp_l(1),2) )^2  )  ;  %  Br_1 表示式 2 中的导数                 
                 delta_beta  =   1 * S_1  * S_2  ;   %  求出来的最终偏导数                 
                 BN( samp_l(1)  ,in1dex)  =  BN( samp_l(1)  ,in1dex)  - delta_beta ;                 
                 JKLOLIN = BN(:,in1dex);
                 JKLOLIN = JKLOLIN/sum(JKLOLIN);                 
                 WTf(:,2,in_top_index(in1dex))  =  JKLOLIN ;
%          disp(JKLOLIN)
             end       %   梯度下降法迭代停止的时刻             
             
             age = age+1;   %  先对所有的进行加一，然后再将个别的赋值为  0
             for ak = 1:3
                 age(  in_top_index(ak)  )  = 0;
             end             
         end
     end
        
        index_age =  find(age>huip);    %   关于阈值的设定
        AA(index_age,:) =  [];
        WTf(:,:,index_age)  =  [];
        age(index_age)  =  [];
         [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k) ;
       curve(2,p11) = ac_er;   
         
         
         
 end         %  大循环结束
 
    
%% 学习完成后，用更改后的规则库对测试集进行测试 

  [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k) ;
  disp(ac_er);

      miko =  size(aJILUJZ,2);
      miko1 =miko -size(Test_Data,1)+1;
      td_1 =  sum(        aJILUJZ(     1, miko1 :miko   )    ) /size(Test_Data,1);
      disp(td_1)
end