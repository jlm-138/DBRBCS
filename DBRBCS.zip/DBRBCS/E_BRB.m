%% D-S融合方法，在BRB_12中被调用
%*******21.11.15
%*******构建D-S融合框架,只对第一个建立规则的样本进行折扣运算 
%%  此函数是一个求融合后置信分配的函数
%%  注意，默认第一列为标签    最后一列为空值   最后一行是分配给辨识框架的置信度      被调用的 

%  D-S融合函数

%%
%求归一化参数K
 function [UFO]=E_BRB(A)
             B=A;
for m_b=1:size(B,1)-1
    B_T=B;           
    B_T(size(B,1),:)=[];                          %  辨识框架那一行相交不为空集，也进行删除
    B_T(m_b,:)=[];                                %  相等的行删除
    B_z=B(m_b,2)*B_T(:,3);
    Zong(m_b)=sum(B_z);
end
     K=1-sum(Zong);                               %  归一化参数K求出。
     
for m_c=1:size(B,1)
   TLS_1(m_c)=(   B(m_c,2)*B(m_c,3)+ B(m_c,2)* B(size(B,1),3) );
end

for m_d=1:size(B,1)
    TLS_2(m_d)=(   B(m_d,3)*B(size(B,1),2)             );

end

      TLS_3=(TLS_1+TLS_2);
      TLS_3(size(B,1))=TLS_3(size(B,1))/3;                                 %除3的原因是因为最后一列被重复计算了3次
      UFO=TLS_3/K;

 end
