%-Functions for calculating the Degree of membership
function [beta]=memship(x,uc,sigmc)
if sigmc==0
    beta=1;
else
    beta=exp(-((x-uc)/sigmc)^2);
end
end