% Feedback updates as experts reason about the belief rules in the loop
function [td_1,td_2]=FZ_EIL(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k,DOI,Nl)
%function [td_1]=FZ_EIL(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k,DOI,Nl)
%%%%%%function:Feedback updates as experts reason about the belief rules in the loop
%%%Input：
%AA:Rule Prerequisites (with language labels)
%Test_Data:
%men:The center point of each feature
%sigmaf:
%WTf:The final confidence distribution for each rule(The second column)
%Ini_e:
%top_k:Threshold for the number of fusion rules
%DOI:Test Data
%Nl:Number of language labels set up
%%%Output：
%td_1：Classification accuracy of DBRBCS

age =  zeros(1,size(AA,1))  ;   %  Generate an all-zero matrix representing the initial rule age
% %%  在开始之前，先对测试集进行一次预测
% [ac_er,~,~,~ , ~] =  ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k) ;
% disp(ac_er)
% ANSWER(1,1) =ac_er;

%% Related Parameter Settings
omicro = 0.3;           %   rule threshold
a = 2;                   %   the parameter in the approximation of the step function
de_num  =  1000;           %   Setting the number of iterations - Gradient descent method
huip = 0.15*size(Test_Data,1)*4 ;    %   Rule age threshold
ro=10^(-3);                  %   Loss Function Equilibrium Factor
Wrong_number=0;
correct_number=0;

for p11 = 1 : size(DOI,1)
    
    samp_l = DOI(p11,:)  ;   
    % Prediction of incoming samples using existing models
    [~,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,samp_l,men,sigmaf,WTf,Ini_e,top_k) ;
  
    if  tag_brb  ==  samp_l(1)
        aJILUJZ(p11)  =  1;
    else
        aJILUJZ(p11)  =  0;
    end
    
    popop(p11)= top_fengbu(1);

    %% There is a new tag, add a rule
    if samp_l(1) > size(WTf,1)-1                   
        
        for y= 2:size(samp_l,2)
            for ss=1:Nl
                cc = samp_l(y)-men(y-1,ss);
                dd(1,ss) = abs(cc);
            end
            [min_cc,dex]=min(dd);
            A_new(y-1)  =  dex;                 
        end
      
        n_class  =  size(WTf,1)-1+1  ;
        A_new_WT  =  zeros(  n_class+1, n_class+2  );
        K_class  =  linspace(1 , n_class+1,  n_class+1  );
        A_new_WT(:,1)  =    K_class' ;
        A_new_WT(size(A_new_WT,1)-1,size(A_new_WT,1)-1) = 1;    
        A_new_WT(size(A_new_WT,1),size(A_new_WT,1)) = 0;
       
        for  J_1 = 1:size(WTf,3)
            
            new_WTf(:,:,J_1)  =  zeros(  n_class+1, n_class+2  );
            K_class  =  linspace(1 , n_class+1,  n_class+1  );
            new_WTf(:,1,J_1)  =    K_class' ;
            new_WTf(1:size(WTf,1)-1,2,J_1)  = WTf(1:size(WTf,1)-1,2,J_1);
            new_WTf(size(new_WTf,1),2,J_1)  = WTf(size(WTf,1),2,J_1);
        end
        WTf = new_WTf;    
        AA   =   [AA;A_new];   
        Ini_e=[Ini_e,zeros(size(Ini_e,1),1);
               zeros(1,size(Ini_e,2)),0];
        age(  size(age,2)+1  ) = 0;
        age(  1:size(age,2)-1  ) =   age(  1:size(age,2)-1  )  +1;
        
        WTf(:,:,size(WTf,3)+1)  =  A_new_WT;    %   添加一条新的规则结论。
    end
    
    
    if top_fengbu(1)  <  omicro   %  Less than predefined rule threshold, add a rule
        samp_l1 = samp_l;
        samp_l1(1) = [];
        for y= 1:size(samp_l1,2)
            for ss=1:Nl
                cc = samp_l1(y)-men(y,ss);
                dd(1,ss) = abs(cc);
            end
            [min_cc,dex]=min(dd);
            A_new(y)  =  dex;                 
        end
        
        n_class  =  size(WTf,1)-1  ;  
        A_new_WT1  =  zeros(  n_class+1, n_class+2  );
        K_class  =  linspace(1 , n_class+1,  n_class+1  );
        A_new_WT1(:,1)  =    K_class' ;
        
        A_new_WT1( samp_l(1) ,2) = 1;     
        A_new_WT1(size(A_new_WT1,1),2) = 0;
        [L,N]=ismember(A_new,AA,'rows');
        if L
        else
        AA   =   [AA;A_new];    
        WTf(:,:,size(WTf,3)+1) = A_new_WT1;    
        age(  size(age,2)+1  ) = 0;
        age(  1:size(age,2)-1  ) =   age(  1:size(age,2)-1  )  +1;
        end

    end
    
    if top_fengbu(1)  >  omicro   % Greater than the rule threshold
        
        if samp_l(1)  ==  tag_brb   % correct classification
            
            in_top_index   ;  
            N_H_TQ =  WTf(:,:,in_top_index(1));   
            N_H_TQ(samp_l(1),3)  = top_fengbu(1) ;   
            N_H_TQ(size(N_H_TQ,1),3)  =   1-top_fengbu(1);
            WTf(:,2,in_top_index(1))   =    E_BRB(  N_H_TQ   )';    
            age = age+1;   
            age(  in_top_index(1)  )  = 0;
        else           %  Misclassification, updating rules
            WTf_initial=WTf;
            min_J=100;
            Wrong_number=Wrong_number+1;
            WTF_finial=WTf;
            target_finial=1;
            J_observe=[];
            for  k=1:de_num
                [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,samp_l,men,sigmaf,WTf,Ini_e,top_k) ;
                if numel(find(isnan(Fengbu_arry(:,2))))~=0
                    t=1;
                end
                H   = ( 1+ Fengbu_arry(tag_brb,2)  )./  (  Fengbu_arry(samp_l(1),2)+1  );
                J1   =  1/(   1+  (  exp( a*(1-H)  )  )  );    
                S_1  =  (  a * exp( a* (1-H)  )  )  /   ( 1+  exp( a*(1-H)  )  )^2   ;
                count=sum(top_fengbu~=0);
                if count>top_k
                    top_k_l=top_k;
                else
                    top_k_l=count;
                end
                in1dex = mod(k,top_k_l);
                if in1dex==0
                    in1dex=top_k_l;
                end
                BN=[];
                for   u  =  1 : top_k_l    
                    BN(:,u) = WTf(:,2,in_top_index(u));         
                end                                            
                J2=0;
                for ve=1:top_k_l
                    J2=J2+(WTf(1:size(WTf,1)-1,2,in_top_index(ve))-WTf_initial(1:size(WTf,1)-1,2,in_top_index(ve)))'*(WTf(1:size(WTf,1)-1,2,in_top_index(ve))-WTf_initial(1:size(WTf,1)-1,2,in_top_index(ve)));
                end
                J2=J2./(top_k_l.*(size(WTf,1)-1));
                if J2~=0
                    np=1;
                end
                J=J1 +ro*J2;
                if  J>min_J
                    if  samp_l(1)  ==  target_finial    
                        WTf=WTF_finial;
                        correct_number=correct_number+1;
                        break
                    end
                    WTf=WTF_finial;
                    break
                else
                    min_J=J;
                    WTF_finial=WTf;
                    target_finial=tag_brb;
                end
                for j = 1:size(BN,2)
                    BN_1( 1:size(BN,1)-1 ,j )  =   BN( 1:size(BN,1)-1 ,j ) * top_fengbu (j) ;
                    BN_1( size(BN,1) ,j )  =   1  -  sum(  BN_1( 1:size(BN,1)-1 ,j )    )   ;
                end
                
                for  v  =  1  :  size(BN,2)    
                    pod(v) =  BN_1( samp_l(1)  ,v) + BN_1(  size(BN_1,1),v )  ;       
                end
                
                F_N   =  prod(pod)  -  prod(  BN_1( size(BN,1) ,: )  ) ;  
                F_N_1 =  top_fengbu (in1dex) *  prod(  BN_1( size(BN,1) ,: )  )/   BN_1 ( size(BN_1,1) , in1dex )  ;  
                for  v  =  1  :  size(BN,2)
                    for vv = 1:size(BN,1)-1
                        BN_L ( vv ,v ) =  BN_1(vv,v ) +BN_1( size( BN_1,1 )  ,v )  ;
                    end
                end
                
                K_0  =    sum( prod(BN_L,2) )  - ( size(BN_L,1)-1-1 )* prod( BN_1( size(BN,1) ,: )    )    ;
                K_N  =  1/K_0  ;     
                K_N_1  =   ( size(BN_1,1)  -1 - 1  )*  (  top_fengbu (in1dex) *  prod(  BN_1( size(BN,1) ,: )  )/   BN_1 ( size(BN_1,1) , in1dex ) )  ;
                K_N_1  = (-1/(K_0)^2 )  *  K_N_1  ;
                Br_1  =  F_N *  K_N_1 + K_N  *  F_N_1  ;   
                S_2  =  - ( (1+ Fengbu_arry(tag_brb,2) )* Br_1  / (  1 +  Fengbu_arry( samp_l(1),2) )^2  )  ;  % 
                delta_beta_1  =   1 * S_1  * S_2  ;   
                delta_beta_2=0;
                for vt=1:top_k_l
                    delta_beta_2=delta_beta_2+2*sum((WTf(1:size(WTf,1)-1,2,in_top_index(vt))-WTf_initial(1:size(WTf,1)-1,2,in_top_index(vt)))');
                end
                delta_beta_2=delta_beta_2./(top_k_l.*(size(WTf,1)-1));
                if  delta_beta_2~=0
                    np=1;
                end
                delta_beta=delta_beta_1+ro*delta_beta_2;
                BN_initial=BN;
                BN( samp_l(1)  ,in1dex)  =  BN( samp_l(1)  ,in1dex)  -1*delta_beta ;%步长为1
                JKLOLIN = BN(:,in1dex);
                bu=sum(JKLOLIN);
                JKLOLIN = JKLOLIN/bu;
                WTf(:,2,in_top_index(in1dex))  =  JKLOLIN ;
            end       
            
            age = age+1;   
            count=sum(top_fengbu~=0);
            if count>top_k
                count_number=top_k;
            else
                count_number=count;
            end
            for ak = 1:count_number
                age(  in_top_index(ak)  )  = 0;
            end
        end
    end
    
    index_age =  find(age>huip);  
    if ~isempty(index_age)
        y=1;
    end
    AA(index_age,:) =  [];
    WTf(:,:,index_age)  =  [];
    age(index_age)  =  [];
    [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =  ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k) ;
    curve(2,p11) = ac_er;
    
    
    
end         

Wrong_number;
correct_number;
miko =  size(aJILUJZ,2);
miko1 =miko -size(Test_Data,1)+1;
td_1 =  sum(        aJILUJZ(     1, miko1 :miko   )    ) /size(Test_Data,1);
td_2=size(WTf,3)
disp(td_1)
consequent=[]
for j=1:size(WTf,3)
   con=WTf(:,:,j);
   consequent=[consequent;con(:,2)'];
end 

end