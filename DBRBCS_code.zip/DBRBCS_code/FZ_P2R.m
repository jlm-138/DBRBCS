%
% Converting prototypical rule premises into the form of language labels
function [AA,men,sigmaf,WTf,Ini_e,top_k,aaa_ZUICHU,Nl]=FZ_P2R(top_k,FF,A,Store_Data,Wp,cnt,Ini_e,Test_Data)
%Function：Rule premises are converted into the form of linguistic labels and the conclusion of the rule is generated
%%input：
%top_k：Number of rule fusion settings
%FF:Number of features
%A:Training data
%Store_Data:Store the serial numbers of the samples that support the premise of the rule
%Wp:Initial rule premise
%cnt:Number of samples supporting each rule premise
%Ini_e:Generalizability matrices to facilitate belief inference
%Test_Data:Test data
%%Output：
%AA:Rule Prerequisites (with language labels)
%men:The center point of each feature
%sigmaf:Standard deviation for each feature
%WTf:The final confidence distribution for each rule(The second column)
%Ini_e:Generalizability matrices to facilitate belief inference
%top_k:Threshold for the number of fusion rules
%aaa_ZUICHU:Classification accuracy of IBRBC
%Nl:Number of language labels set up
%%
WP2 = Wp;        
cnt2 = cnt;      
lamda = 0.01;   
Nl = 3;  %Number of language labels set up

[min_a,index1] = min(WP2);
[max_a,index] = max(WP2);

NL = Nl*ones(1,size(WP2,2));   
%% Step 2 - Calculate the center of each feature obtained by employing the idea of equalized partitioning, expressed using the men matrix
for i1=1:size(WP2,2)     
    Vmin(i1)=min_a(i1);
    Vmax(i1)=max_a(i1);
    res(i1)=(Vmax(i1)-Vmin(i1))/(NL(i1)-1);
    sigmaf(i1)=sqrt(-res(i1)^2/(sqrt(2)*log(lamda)));
    men(i1,1)=Vmin(i1);
    for j1=2:NL(i1)
        men(i1,j1) =men(i1,j1-1)+res(i1);
    end
end
%% Step 3---Mapping Rule Prerequisites
for h=1:size(WP2,1)
    for y=1:size(WP2,2)
        for ss=1:Nl
            cc=WP2(h,y)-men(y,ss);
            dd(1,ss)=abs(cc);
        end
        [min_cc,dex]=min(dd);
        AA(h,y)=dex;
    end
end
%%
% Calculate the belief distribution of the conclusions of the rule.
arry_ini =  Ini_e;
for k=1:size(Wp,1)
    WT(:,:,k) = arry_ini;    %  Belief distributions in the process
    WTf(:,:,k) = arry_ini;   %  Final belief distribution
end

for m_h1=1:size(Store_Data,1)        
    clear fire;  
    for m_h2=1:size(Store_Data,2)
        S_index = Store_Data(m_h1,m_h2);  
        if S_index==0
            continue
        end
        p_h  =  A(S_index,:);    
        for j=1:FF                                                        
            lb_6 = AA(m_h1,j);   
            if lb_6 ==0
                fire(m_h1,j) =1;
                continue
            else
                ZM  =  men(j,lb_6);    
                fire(m_h1,j)  =  memship(p_h(:,j+1),ZM,sigmaf(j));  
            end
        end
        M_N = prod(  fire(m_h1,:)   );
        M_N = M_N.^(1/FF);  
        if sum( WT(p_h(1),p_h(1)+1,m_h1) ) == 0  
            WT(p_h(1),p_h(1)+1,m_h1)   = M_N;%  max_M;
            WT(size(arry_ini,1),p_h(1)+1,m_h1)   =  1-M_N;% 1-max_M;      
            WT(  p_h(1),size(arry_ini,2),m_h1)   =   1;                           
        else             
            arry_ini = Ini_e ;         
            arry_ini(:,2)=WT(:,p_h(1)+1,m_h1);                      
            arry_ini(p_h(1),3) = M_N  ;          %  max_M;                              
            arry_ini(size(arry_ini,1),3)= 1-M_N; %   1-max_M;             
            WT(:,p_h(1)+1,m_h1) = E_BRB(   arry_ini  )';      
            WT(p_h(1),size(arry_ini,2),m_h1)   =  WT(p_h(1),size(arry_ini,2),m_h1)+1 ;                        
        end
    end    
end   

%%  inter-classification

WT_=WT;    
for m_f1=1:size(WT,3)
    pi_1 = sum(WT(:,size(WT,1)+1,m_f1));       
    for m_f2=1:size(WT,1)
        WT(m_f2,size(WT,1)+1,m_f1)  =  WT(m_f2,size(WT,1)+1,m_f1)/pi_1;
    end
end
f_n  =  size(arry_ini,1)-1;     
f_m  =  size(arry_ini,2)-1;

for i_o = 1:size(WT,3)    
    
    index_d  =  find(   WT(:,size(WT,2),i_o) >0 );  
    for i_d = 1 : size (index_d,1)
        
        factor    =   WT( index_d(i_d) ,  size(WT,2)  ,i_o)  ;  
        WT(  index_d(i_d),  index_d(i_d)+1  ,i_o)    =   WT(  index_d(i_d),  index_d(i_d)+1  ,i_o)*factor;
        WT(  size(arry_ini,1),  index_d(i_d)+1  ,i_o)   =  WT(  size(arry_ini,1),  index_d(i_d)+1  ,i_o)*factor + (1-factor);
    end
end



for m_f1=1:size(WT,3)      
    mf_index = find(   WT(:,size(WT,2),m_f1) >0 );  
    if size(mf_index,1)==1   
        WTf(:,2,m_f1)  =  WT(  : , mf_index(1)+1 , m_f1);
        continue
    end
    GuoDu_f1  =  Ini_e;
    GuoDu_f1(:,2)  =  WT(  :,mf_index(1)+1,m_f1) ;
    for m_f2  =  2:size(mf_index,1)       
        
        GuoDu_f1(:,3)  =  WT(  :,mf_index(m_f2)+1,m_f1) ;
        GuoDu_f1(:,2)  =  E_BRB(   GuoDu_f1  )';
    end          
    WTf(:,2,m_f1) = GuoDu_f1(:,2);    
end  
WT1 =  WTf;

%%  Rules that share the same rule premise are fused into a single rule!
you = unique( AA,'rows' );
for  k = 1 : size(you,1)
    Rule_A = you(k,:);
    RULE= repmat(Rule_A ,size(AA,1),1);
    DE_RULE  = abs( RULE  -AA  );
    sum_de =  sum (DE_RULE,2);
    de__index  =  find(sum_de==0);  
    if  size(de__index,1) > 1
        
        GuoDu_f1  =  Ini_e;
        GuoDu_f1(:,2)  =  WTf(  :,2,de__index(1) ) ;
        
        for plc  =  2:size(de__index,1)       
            
            GuoDu_f1(:,3)  =  WTf(  :,2,de__index(plc)  ) ;
            GuoDu_f1(:,2)  =  E_BRB(   GuoDu_f1  )';
            
        end       
        
        WTf(:,2, de__index(1)) =  GuoDu_f1(:,2) ;
        de__index(1) = [];
        AA(de__index,:)      =  [];
        WTf(:,:,de__index)   =  []; 
    else  
        continue   
    end
    
end
%%Classification about the test dataset
[aaa_ZUICHU,~,~,~,~]=ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k);    %   返回值为精度与预测值
disp( aaa_ZUICHU)

DATA_DRIVEN_RULE = AA ;
data_driven_wt = WTf;
consequent=[]
for j=1:size(WTf,3)
   con=WTf(:,:,j);
   consequent=[consequent;con(:,2)'];
end 
end