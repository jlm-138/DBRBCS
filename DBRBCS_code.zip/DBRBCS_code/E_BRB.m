%%  D-S fusion method
%%  Note that by default, the first column is the label, the last column is the null value, and the last row is the confidence level assigned to the recognition framework. 
%Obtain the normalization parameter K
 function [UFO]=E_BRB(A)
             B=A;
for m_b=1:size(B,1)-1
    B_T=B;           
    B_T(size(B,1),:)=[];                         
    B_T(m_b,:)=[];                               
    B_z=B(m_b,2)*B_T(:,3);
    Zong(m_b)=sum(B_z);
end
     K=1-sum(Zong);                               
     
for m_c=1:size(B,1)
   TLS_1(m_c)=(   B(m_c,2)*B(m_c,3)+ B(m_c,2)* B(size(B,1),3) );
end

for m_d=1:size(B,1)
    TLS_2(m_d)=(   B(m_d,3)*B(size(B,1),2)             );

end

      TLS_3=(TLS_1+TLS_2);
      TLS_3(size(B,1))=TLS_3(size(B,1))/3;                                 
      UFO=TLS_3/K;

 end
