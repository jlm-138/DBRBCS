clc,clear
load ('xxxxxxx');
top_k = 3;
for fold = 1:5
    DATA_TRAIN = TrainingData{fold};
    DATA_TEST = TestData{fold};
    [Store_Data,Wp,cnt,Ini_e,A,FF,DOI] =  FZ_BRB_12(DATA_TRAIN,DATA_TEST);
    [AA,men,sigmaf,WTf,Ini_e,top_k,aaa_ZUICHU,Nl] = FZ_P2R(top_k,FF,A,Store_Data,Wp,cnt,Ini_e,DATA_TEST); % Translating rule premises and learning rule conclusions
    result1(fold) = aaa_ZUICHU;  % Results of IBRBC classification
    [td_1,td_2]=FZ_EIL(AA,DATA_TEST,men,sigmaf,WTf,Ini_e,top_k,DOI,Nl); % Experts update belief rules in loop
    result2(fold) = td_1 ; %  Results of DBRBCS classification
    result3(fold) = td_2;
end