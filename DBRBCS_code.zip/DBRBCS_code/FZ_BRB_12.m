%%  Learning Initial Prototype Rule Prerequisites
function [Store_Data,Wp,cnt,Ini_e,A,FF,DOI]=FZ_BRB_12(TRAIN_X,TEST_X)
%%%%% function：Learning initial prototype rule premises from training samples
%%%Input：
%TRAIN_X:Training data
%TEST_X: Testing data
%%%Output：
%Store_Data:Store the serial numbers of the samples that support the premise of the rule
%Wp:Storage rule prerequisites
%cnt:Number of samples supporting each rule premise
%Ini_e:Generalizability matrices to facilitate belief inference
%A:Training data
%FF:Number of features
%DOI:Test data
% 2022.06.10

ONE = TRAIN_X ;       
a=[ONE(:,1);TEST_X(:,1)];
b_ = unique (a);         % class label
n_class = size(b_,1);    % Number of class labels

BiLi = 1;
Ini_e  =  zeros(  n_class+1, n_class+2  );
K_class  =  linspace(1 , n_class+1,  n_class+1  );
Ini_e(:,1)  =    K_class' ;

%%  Dataset Settings
 A=ONE;
 DOI =  TEST_X ; 
%% parameter setting
FF = size(A,2)-1 ;                                                        %Number of features in the dataset
disp(FF)
epsilon=0.75;                                                             %Setting the initial threshold parameter
sigma0 = 1 ;                                                              %Setting the initial standard deviation
% Construct the prerequisite part of the first rule 
p=A(1,1:FF+1);
Wp(1,:)=p(1,2:FF+1);                                                       
cnt(1)=1;                                                                  
sigma(1,:)=ones([1,FF])*sigma0;                                            
Store_Data(1,1)=1;  

%Learning from the second sample
for m=2:size(A,1)                                                              
        p=A(m,1:FF+1);  
        % Calculate the membership of each sample to the premise of the rule
        for l=1:size(Wp,1)                                                     
            for j=1:FF                                                            
                K(j)=sigma(l,j);                                                  
                W(j)=(Wp(l,j)-p(j+1))^2;                                          
            end
            B(l)=sqrt(sum(W))^2;                                                   
            U(l)=(sum(K))/FF;                                                     
            M(l)=exp((-B(l)/(2*U(l)^2)));                                       
        end
      M = M.^(1/FF);                                                                                                     

    [max_M,index]=max(M,[],2);                                            
    index_ep=find(M>epsilon);                                             
                                                                                                                                
    if size(index_ep,2)>0
        %Updating rule prerequisites and related parameters
        for h=1:size(index_ep,2)
            cnt( index_ep(h) )  =  cnt(index_ep(h))+1;                                        
            qa=1-(1/cnt(index_ep(h)));
            for k=1:FF
                Wp(index_ep(h),k)=(Wp(index_ep(h),k)*(cnt(index_ep(h))-1)+p(k+1))/(cnt(index_ep(h)));   
                qb  =  (  Wp(index_ep(h),k)-p(k+1)  )^2;
                sigma(index_ep(h),k)   =   sqrt(qa*((sigma(index_ep(h),k)^2))+(qb/cnt(index_ep(h))));
            end                                                                
            sum_GuoDu  =  size(Store_Data(index_ep(h),:),2);
            Store_Data(index_ep(h),sum_GuoDu+1)  =  m;                                   
        end
    else                       
        %Add a new rule for coarse division
        Wp(size(Wp,1)+1,:)  =  p(:,2:FF+1);                                   
        cnt(size(Wp,1))  =  1;
        sigma(size(Wp,1),:)  =  ones([1,FF])*sigma0;
        Store_Data(size(Wp,1),1)  =  m;
    end
end    

disp('num of wp')
disp(size(Wp,1))
end