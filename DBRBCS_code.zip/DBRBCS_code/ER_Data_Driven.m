%%  Using ER inference methods for new samples
%%  top k rules for fusion
function [ac_er,tag_brb,Fengbu_arry,top_fengbu , in_top_index] =ER_Data_Driven(AA,Test_Data,men,sigmaf,WTf,Ini_e,top_k)
%%%Input：
%AA:Rule Prerequisites (with language labels)
%Test_Data:
%men:The center point of each feature
%sigmaf:Standard deviation for each feature
%WTf:The final confidence distribution for each rule(The second column)
%Ini_e:
%top_k:Threshold for the number of fusion rules
%%%Output：
%ac_er：Test sample classification correctness
%tag_brb:Predictive class labeling of sample
%Fengbu_arry：The second column shows the distribution of forecasts for the latest sample of forecasts
%top_fengbu：Activation of the sample
%in_top_index：Index of the first top-k activation rules

FES  =  AA;   
num_final=0;

for k_d =  1:size(Test_Data,1)
    
    Sam_ple  =  Test_Data(k_d,:);  
    for j=1:size(FES,1)                
        for k=1:size(FES,2)             
            ZC=FES(j,k);            
            if men(k,3)-men(k,1)<=10^(-6)      
                cfes(j,k)  =  1;      
                continue                  
            else               
                ZM   =  men(k,ZC);     
                cfes(j,k)=memship(Sam_ple(:,k+1),ZM,sigmaf(k)); 
            end
        end
    end   
    if sum(prod(cfes,2))==0
        Cheng_ji=sum(cfes,2);
    else
     Cheng_ji = prod(cfes,2);
    end
    Cheng_ji = Cheng_ji.^(  1/(  size(AA,2)  )   );     
    [top_fengbu , in_top_index] = sort(Cheng_ji,1,'descend');
    count=sum(top_fengbu~=0);
%     if size(in_top_index,1) < top_k
    if count < top_k
        top_k_l = count;
    else
        top_k_l = top_k;
    end
    
    for top = 1:top_k_l   
        Lin_Shi(:,:,top) =  Ini_e ;
        Lin_Shi(:,2,top) =  WTf(:,2, in_top_index(top) )   * top_fengbu(top)  ;
        Lin_Shi(size(Lin_Shi,1),2,top) = Lin_Shi(size(Lin_Shi,1),2,top) * top_fengbu(top)  + 1 - top_fengbu(top);
    end
    
    final_er = Ini_e;
    final_er(:,2) = Lin_Shi(:,2,1) ;   
    for er_2 = 2:top_k_l
        final_er(:,3)  =  Lin_Shi(:,2,er_2) ;
        final_er(:,2)  =  E_BRB(final_er)';
    end
    
    Fengbu_arry = final_er;    
    if numel(find(isnan(Fengbu_arry(:,2))))~=0
        t=1;
    end
    final_er(size(final_er,1),:) = [];     
    [~,final_index]=max(final_er(:,2));   
    tag_brb  =    final_er(final_index,1);
    if final_er(final_index,1)==Sam_ple(1)
        num_final = num_final+1;
    end
end  
ac_er=num_final/size(Test_Data,1);
end